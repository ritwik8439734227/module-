export interface studentDetails
{
    id : string;
    name : string;
    city : string;
}